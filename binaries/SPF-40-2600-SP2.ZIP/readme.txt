
                  SPF/SourceEdit 4.0 Install

  SPF/SourceEdit 4.0 comes with two interface options:

  1) GUI  - A native mode Windows GUI style interface with Windows
            menu bar. Windows modal dialogs are presented for all
            interaction except File List and Edit which have an SPF
            style interface with a primary command field. Recommended
            mode of interaction is via mouse.

  2) 3270 - A character mode 3270 style panel user interface with
            primary command field for all menus, dialogs, File List
            and Edit. There are no menu bars, tool bars, scroll bars
            or other GUI type appliances. Recommended mode of
            interaction is via keyboard.

  These interface options are distinct applications and do not
  inter-operate. They are installed in different directories and use
  different executables and control files.


  Installing SPF/SE 4.0 From Floppy Disk
  --------------------------------------

  * If you received the SPF/SE retail box package, you received two
    floppy disks:

  * If you want to install the GUI interface option as described
    above, insert the disk labeled "GUI Interface Option" into floppy
    disk drive A:.

  * If you want to install the 3270 interface option as described
    above, insert the disk labeled "3270 Interface Option" into floppy
    disk drive A:.
   
  * In Windows explorer, in the folders panel, double-click on the A:
    drive icon.  This displays the A: floppy disk file content.

  * Double-click on file entry INSTALL.EXE.

  * If you are not sure which interface style you prefer, you can
    install both by running install from each of the two floppy disks.

   
  Installing SPF/SE 4.0 From Electronically Shippped File
  -------------------------------------------------------

  * If you received SPF/SE electronically, you received file
    SPFSE40.EXE as an attachment to an explanatory e-mail. This file
    contains the elements necessary for installation of the GUI
    Interface Option and the 3270 Interface Option as described above.

  * File SPFSE40.EXE is a self expanding ZIP file. Following the
    instructions provided in the e-mail text you have already created
    directory C:\DISKSPFSE40 and unzipped file SPFSE40.EXE by
    executing it.
   
  * To install SPF/SE 4.0, invoke Windows Explorer. In the Explorer
    folders panel, double-click on folder C:\DISKSPFSE40. The files
    therein are now visible. To install, double-click on file
    INSTALL.EXE.

    If you want to install the GUI interface option, respond to the
    Interface Option prompt with GUI.
   
    If you want to install the 3270 interface option, respond to the
    Interface Option prompt with 3270.
   
  * If you are not sure which interface style you prefer, you can
    install both by running INSTALL.EXE twice.


  Installing SPF/SE 4.0 DEMO From Downloaded File
  -----------------------------------------------

  * You downloaded SPFSE40DEMO.EXE from our web site. This file
    contains the elements necessary for installation of the
    demonstration version of the GUI Interface Option and the 3270
    Interface Option as described above.

  * File SPFSE40DEMO.EXE is a self expanding ZIP file. Following the
    instructions provided on the web site you have already created
    directory C:\DISKSPFDEMO and unzipped file SPFSE40DEMO.EXE by
    executing it.
   
  * To install SPF/SE 4.0 DEMO, invoke Windows Explorer. In the
    Explorer folders panel, double-click on folder C:\DISKSPFDEMO. The
    files therein are now visible. To install, double-click on file
    INSTALL.EXE.

    If you want to install the GUI interface option, respond to the
    Interface Option prompt with GUI.
   
    If you want to install the 3270 interface option, respond to the
    Interface Option prompt with 3270.
   
  * If you are not sure which interface style you prefer, you can
    install both by running INSTALL.EXE twice.


  Common to All Install Modes
  ---------------------------

  By default, each interface option installs in its own directory.
  This allows for concurrent operation without interaction of the two
  interface modes. In this way you can try each mode to determine
  which best fits your needs.

  The default install directory is also designed to prevent
  interaction with earlier versions of SPF/SE.

  If you do not accept the default install directory,

  * DO NOT INSTALL BOTH INTERFACE OPTIONS IN THE SAME DIRECTORY.

  * DO NOT INSTALL IN THE INSTALL DIRECTORY OF AN EARLIER VERSION OF
    SPF/SE.


  After Install
  -------------

  If you accepted the default install directory, the install program
  created a desktop icon for SPF and a Windows Start Menu folder.

  If you specified a custom install directory, you will have to create
  the desktop icon and Windows Start Menu folder yourself.

